﻿using Microsoft.Data.SqlClient;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfDB
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ManageCategories  categoryService;
        private int selectedCategoryId;
        public MainWindow()
        {
            InitializeComponent();
            categoryService = new ManageCategories();
            LoadCategories();
        }

        private void LoadCategories()
        {
            dataGridCategories.ItemsSource = categoryService.GetCategories();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCategoryId > 0)
            {
                categoryService.DeleteCategory(selectedCategoryId);
                LoadCategories();
                txtCategoryName.Clear();
                selectedCategoryId = 0;
            }
            else
            {
                MessageBox.Show("Please select a category to delete.");
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (selectedCategoryId > 0 && !string.IsNullOrWhiteSpace(txtCategoryName.Text))
            {
                categoryService.UpdateCategory(selectedCategoryId, txtCategoryName.Text);
                LoadCategories();
                txtCategoryName.Clear();
                selectedCategoryId = 0;
            }
            else
            {
                MessageBox.Show("Please select a category and enter a new name.");
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtCategoryName.Text))
            {
                categoryService.AddCategory(txtCategoryName.Text);
                LoadCategories();
                txtCategoryName.Clear();
            }
            else
            {
                MessageBox.Show("Please enter a category name.");
            }
        }

        private void dataGridCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridCategories.SelectedItem is Category selectedCategory)
            {
                selectedCategoryId = selectedCategory.CategoryID;
                txtCategoryName.Text = selectedCategory.CategoryName;
                txtCategoryID.Text = selectedCategory.CategoryID.ToString();
            }
        }

    
    }
}